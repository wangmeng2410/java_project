package com.fcq.schedule.job.dao;

import org.hibernate.HibernateException;

import com.fcq.schedule.job.po.User;

public interface BaseDao {
	public void saveObject(Object obj) throws HibernateException;

	public Object findByUsernameAndPassword(User user) throws HibernateException;

}
