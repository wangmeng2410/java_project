package com.fcq.schedule.job.dao;

import org.hibernate.HibernateException;

import com.fcq.schedule.job.po.Goods;

public interface GoodsDao {

	public Object modifyGoodsByNum(Goods goods) throws HibernateException;

	public Object findGoodsByNum(Goods goods) throws HibernateException;

	public Object getFirstGoods() throws HibernateException;
}
