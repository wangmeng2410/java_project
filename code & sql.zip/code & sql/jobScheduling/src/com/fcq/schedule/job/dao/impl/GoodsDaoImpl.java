package com.fcq.schedule.job.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.fcq.schedule.job.dao.GoodsDao;
import com.fcq.schedule.job.po.Goods;

public class GoodsDaoImpl implements GoodsDao {

	private HibernateTemplate hibernateTemplate;

	@Override
	public Object modifyGoodsByNum(Goods goods) throws HibernateException {
		String hql = "update Goods set goodsName=?, goodsPrice=?, goodsStock=? where goodsNum=?";
		hibernateTemplate.update(hql, goods);
		return goods;
	}

	@Override
	public Object findGoodsByNum(Goods goods) throws HibernateException {
		Goods goodsContents = new Goods();

		String hql = "from Goods where goodsNum=?";
		List<Goods> list = (List<Goods>) hibernateTemplate.find(hql, goods.getGoodsNum());
		goodsContents = list.get(0);
		return goodsContents;
	}

	@Override
	public Object getFirstGoods() throws HibernateException {
		Goods goodsContents = new Goods();

		String hql = "from Goods where goodsNum='9527'";
		List<Goods> list = (List<Goods>) hibernateTemplate.find(hql);
		goodsContents = list.get(0);
		return goodsContents;
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

}
