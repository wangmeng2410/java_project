package com.fcq.schedule.job.po;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public class User implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer userId;
	private String username;
	private String email;
	private String password;

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		User user = (User) obj;
		return this.username.equals(user.getUsername()) && this.password.equals(user.getPassword());
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "userId:" + userId + " username:" + username;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
