package com.fcq.schedule.job.service;

import com.fcq.schedule.job.po.Goods;

public interface GoodsManager {
	
	public Goods modifyGoodsByNum(Goods goods);

	public Goods findGoodsByNum(Goods goods);
	
	public Goods getFirstGoods();
}
