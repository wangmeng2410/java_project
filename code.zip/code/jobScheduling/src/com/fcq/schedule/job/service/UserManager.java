package com.fcq.schedule.job.service;

import java.util.List;
import java.util.Set;

import com.fcq.schedule.job.po.User;

public interface UserManager {

	public void regUser(User user);

	public User findUser(User user);

}
