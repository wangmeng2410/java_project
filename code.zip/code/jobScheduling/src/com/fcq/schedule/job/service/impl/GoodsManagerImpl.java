package com.fcq.schedule.job.service.impl;

import com.fcq.schedule.job.dao.GoodsDao;
import com.fcq.schedule.job.po.Goods;
import com.fcq.schedule.job.service.GoodsManager;

public class GoodsManagerImpl implements GoodsManager {

	private GoodsDao goodsDao;

	@Override
	public Goods modifyGoodsByNum(Goods goods) {
		return (Goods) goodsDao.modifyGoodsByNum(goods);
	}

	@Override
	public Goods findGoodsByNum(Goods goods) {
		return (Goods) goodsDao.findGoodsByNum(goods);
	}

	@Override
	public Goods getFirstGoods() {
		return (Goods) goodsDao.getFirstGoods();
	}

	public GoodsDao getGoodsDao() {
		return goodsDao;
	}

	public void setGoodsDao(GoodsDao goodsDao) {
		this.goodsDao = goodsDao;
	}

}
