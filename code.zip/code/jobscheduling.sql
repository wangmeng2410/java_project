/*
Navicat MySQL Data Transfer

Source Server         : jobScheduling
Source Server Version : 80016
Source Host           : localhost:3306
Source Database       : jobscheduling

Target Server Type    : MYSQL
Target Server Version : 80016
File Encoding         : 65001

Date: 2019-06-23 09:15:10
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `goodsNum` varchar(12) NOT NULL,
  `goodsName` varchar(12) NOT NULL,
  `goodsPrice` varchar(12) DEFAULT NULL,
  `goodsStock` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`goodsNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('9527', '华为手机', '13982', '332222221');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userId` int(12) NOT NULL AUTO_INCREMENT,
  `username` char(18) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '111', '1111@111.com', '111111');
INSERT INTO `user` VALUES ('2', 'aaa', 'aaa@aa.com', 'aaaaaa');
INSERT INTO `user` VALUES ('3', 'bbb', 'bbb@b.com', 'bbbbbb');
