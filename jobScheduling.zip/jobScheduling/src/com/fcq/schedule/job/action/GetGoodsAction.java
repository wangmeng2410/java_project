package com.fcq.schedule.job.action;

import java.util.Map;

import com.fcq.schedule.job.po.Goods;
import com.fcq.schedule.job.service.GoodsManager;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class GetGoodsAction extends ActionSupport  {

	private static final long serialVersionUID = 1L;
	private Goods goods;
	private GoodsManager goodsManager;
	
	@Override
	public String execute() throws Exception {
		Map session = ActionContext.getContext().getSession();
		goods = goodsManager.findGoodsByNum(goods);
		if (goods != null) {
			session.put("goods", goods);
			return SUCCESS;
		}
		
		return ERROR;
	}

	public Goods getGoods() {
		return goods;
	}

	public void setGoods(Goods goods) {
		this.goods = goods;
	}

	public GoodsManager getGoodsManager() {
		return goodsManager;
	}

	public void setGoodsManager(GoodsManager goodsManager) {
		this.goodsManager = goodsManager;
	}
}
