package com.fcq.schedule.job.action;

import java.util.Map;

import com.fcq.schedule.job.po.Goods;
import com.fcq.schedule.job.po.User;
import com.fcq.schedule.job.service.GoodsManager;
import com.fcq.schedule.job.service.UserManager;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * 登录
 * 
 * @author 撒旦的奶爸
 *
 */
public class LoginAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	private User user;
	private UserManager userManager;
	private Goods goods;
	private GoodsManager goodsManager;

	@Override
	public String execute() throws Exception {
		try {
			if ((user = userManager.findUser(user)) != null) {
				Map session = ActionContext.getContext().getSession();
				session.put("user", user);
				
				goods = goodsManager.getFirstGoods();
				session.put("goods", goods);
				
				return SUCCESS;
			} else {
				return ERROR;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserManager getUserManager() {
		return userManager;
	}

	public void setUserManager(UserManager userManager) {
		this.userManager = userManager;
	}

	public Goods getGoods() {
		return goods;
	}

	public void setGoods(Goods goods) {
		this.goods = goods;
	}

	public GoodsManager getGoodsManager() {
		return goodsManager;
	}

	public void setGoodsManager(GoodsManager goodsManager) {
		this.goodsManager = goodsManager;
	}
}
