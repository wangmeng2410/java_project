package com.fcq.schedule.job.action;

import java.util.Map;

import org.springframework.util.StringUtils;

import com.fcq.schedule.job.po.User;
import com.fcq.schedule.job.service.UserManager;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * 注册
 * 
 * @author 撒旦的奶爸
 *
 */
public class RegisterAction extends ActionSupport {// Actionsupport这个工具类在实现了Action接口的基础上还定义了一个validate()方法,重写该方法,它会在execute()方法之前执行,如校验失败,会转入input处，必须在配置该Action时配置input属性。
	private static final long serialVersionUID = 1L;
	private User user;
	private UserManager userManager;

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		try {
			if (StringUtils.isEmpty(user.getUsername()) 
					|| StringUtils.isEmpty(user.getEmail()) 
					|| StringUtils.isEmpty(user.getPassword())) {
				return ERROR;
			}
			userManager.regUser(user);
			Map session = ActionContext.getContext().getSession();
			session.put("user", user);
			System.out.println(user.getUsername());
			return SUCCESS;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return ERROR;
		}
	}

	public UserManager getUserManager() {
		return userManager;
	}

	public void setUserManager(UserManager userManager) {
		this.userManager = userManager;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
