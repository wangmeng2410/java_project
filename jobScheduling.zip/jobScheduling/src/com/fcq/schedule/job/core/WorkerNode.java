package com.fcq.schedule.job.core;

/**
 * 用来简化User类
 * 
 * @author 撒旦的奶爸
 *
 */
public class WorkerNode implements Comparable<WorkerNode> {
	private Integer id;// 真实ID
	private Integer avail;// worker空闲的时刻（即worker做完某一项工作的时间）

	public WorkerNode(Integer id) {
		this.id = id;
		this.avail = 0;
	}

	@Override
	public int compareTo(WorkerNode o) {
		// TODO Auto-generated method stub
		int m = o.getAvail();
		if (avail < m)
			return -1;
		if (avail == m)
			return 0;
		return 1;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if (obj == null) {
			return false;
		} else if (obj instanceof WorkerNode) {
			WorkerNode j = (WorkerNode) obj;
			if (this.id == j.getId()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ""+id;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAvail() {
		return avail;
	}

	public void setAvail(Integer avail) {
		this.avail = avail;
	}

}
