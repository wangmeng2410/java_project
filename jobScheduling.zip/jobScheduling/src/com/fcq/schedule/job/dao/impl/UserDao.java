package com.fcq.schedule.job.dao.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.fcq.schedule.job.dao.BaseDao;
import com.fcq.schedule.job.po.User;

public class UserDao implements BaseDao {
	private HibernateTemplate hibernateTemplate;

	/**
	 * 保存用户
	 */
	@Override
	public void saveObject(Object obj) throws HibernateException {
		// TODO Auto-generated method stub
		try {
			hibernateTemplate.save((User) obj);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	/**
	 * 通过用户名和密码查找用户
	 */
	@Override
	public User findByUsernameAndPassword(User user) throws HibernateException {
		// TODO Auto-generated method stub
		List<User> list = null;
		try {
			String hql = "from User  where  username=? and password=?";
			list = (List<User>) hibernateTemplate.find(hql, user.getUsername(), user.getPassword());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

}
