package com.fcq.schedule.job.service.impl;

import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;

import com.fcq.schedule.job.dao.BaseDao;
import com.fcq.schedule.job.po.User;
import com.fcq.schedule.job.service.UserManager;

public class UserManagerImpl implements UserManager {
	private BaseDao userDao;
	// private Session session;

	/**
	 * 注册用户
	 */
	@Override
	public void regUser(User user) throws HibernateException {
		userDao.saveObject(user);
	}

	/**
	 * 查找用户
	 * 
	 * @param user
	 */
	@Override
	public User findUser(User user) {
		// TODO Auto-generated method stub
		return (User) userDao.findByUsernameAndPassword(user);
	}

	public BaseDao getUserDao() {
		return userDao;
	}

	public void setUserDao(BaseDao userDao) {
		this.userDao = userDao;
	}

}
